/**
 * @enum {number}
 */
const CustomElementState = {
  custom: 1,
  failed: 2,
};

export default CustomElementState;
